# [www.developerlibs.com](https://www.developerlibs.com)

In Flutter, Sliver App bar is designed to be used as a direct child of an App Bar. [Read me here](https://www.developerlibs.com/2018/08/flutter-collapsing-toolbar-layout.html)

[YouTube](https://youtu.be/u4sMq7uOtcY) ,
[Facebook](https://www.facebook.com/developerlibs), 
[G+](https://plus.google.com/109457600203481575432),
[Instagram](https://www.instagram.com/developerlibs/), 
[Twitter](https://twitter.com/LibsDeveloper)

![ScreenShot](https://github.com/DeveloperLibs/flutter_collapsing_toolbar/blob/master/screen/collapsgif.gif)
