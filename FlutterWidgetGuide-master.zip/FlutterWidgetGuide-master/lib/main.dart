import 'package:flutter/material.dart';
import 'package:flutter_widget_guide/myapp.dart';

void main() => runApp(MyApp());
