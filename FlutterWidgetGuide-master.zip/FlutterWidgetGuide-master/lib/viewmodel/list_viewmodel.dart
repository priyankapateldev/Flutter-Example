import 'package:flutter_widget_guide/model/list_Item.dart';
import 'package:flutter_widget_guide/utils.dart';

class ListViewModel {
  List<ListItem> listItems;

  ListViewModel({this.listItems});

  getListItems() {
    return listItems = <ListItem>[
      ListItem(
          title: "${Utils.safeArea.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.safeAreaDescription}",
          url: "${Utils.safeAreaURL}",
          mediumUrl: "${Utils.safeAreaMediumUrl}",
          videoUrl: "${Utils.safeAreaVideoUrl}"),
      ListItem(
          title: "${Utils.expanded.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.expandedDescription}",
          url: "${Utils.expandedURL}",
          mediumUrl: "${Utils.expandedMediumUrl}",
          videoUrl: "${Utils.expandedVideoUrl}"),
      ListItem(
          title: "${Utils.wrap.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.wrapDescription}",
          url: "${Utils.wrapURL}",
          mediumUrl: "${Utils.wrapMediumUrl}",
          videoUrl: "${Utils.wrapVideoUrl}"),
      ListItem(
          title: "${Utils.animatedContainer.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.animatedContainerDescription}",
          url: "${Utils.animatedContainerURL}",
          mediumUrl: "${Utils.animatedContainerMediumUrl}",
          videoUrl: "${Utils.animatedContainerVideoUrl}"),
      ListItem(
          title: "${Utils.opacity.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.opacityDescription}",
          url: "${Utils.opacityURL}",
          mediumUrl: "${Utils.opacityMediumUrl}",
          videoUrl: "${Utils.opacityVideoUrl}"),
      ListItem(
          title: "${Utils.futureBuilder.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.futureBuilderDescription}",
          url: "${Utils.futureBuilderURL}",
          mediumUrl: "${Utils.futureBuilderMediumUrl}",
          videoUrl: "${Utils.futureBuilderVideoUrl}"),
      ListItem(
          title: "${Utils.fadeTransition.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.fadeTransitionDescription}",
          url: "${Utils.fadeTransitionURL}",
          mediumUrl: "${Utils.fadeTransitionMediumUrl}",
          videoUrl: "${Utils.fadeTransitionVideoUrl}"),
      ListItem(
          title:
              "${Utils.floatingActionButton.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.floatingActionButtonDescription}",
          url: "${Utils.floatingActionButtonURL}",
          mediumUrl: "${Utils.fabMediumUrl}",
          videoUrl: "${Utils.fabVideoUrl}"),
      ListItem(
          title: "${Utils.pageView.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.pageViewDescription}",
          url: "${Utils.pageViewURL}",
          mediumUrl: "${Utils.pageViewMediumUrl}",
          videoUrl: "${Utils.pageViewVideoUrl}"),
      ListItem(
          title: "${Utils.table.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.tableDescription}",
          url: "${Utils.tableURL}",
          mediumUrl: "${Utils.tableMediumUrl}",
          videoUrl: "${Utils.tableVideoUrl}"),
      ListItem(
          title: "${Utils.sliverAppBar.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.sliverAppBarDescription}",
          url: "${Utils.sliverAppBarURL}",
          mediumUrl: "${Utils.sliverAppBarMediumUrl}",
          videoUrl: "${Utils.sliverAppBarVideoUrl}"),
      ListItem(
          title: "${Utils.sliverList.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.sliverListDescription}",
          url: "${Utils.sliverListURL}",
          mediumUrl: "${Utils.sliverListMediumUrl}",
          videoUrl: "${Utils.sliverListVideoUrl}"),
      ListItem(
          title: "${Utils.sliverGrid.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.sliverGridDescription}",
          url: "${Utils.sliverGridURL}",
          mediumUrl: "${Utils.sliverGridMediumUrl}",
          videoUrl: "${Utils.sliverGridVideoUrl}"),
      ListItem(
          title: "${Utils.fadeInImage.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.fadeInImageDescription}",
          url: "${Utils.fadeInImageURL}",
          mediumUrl: "${Utils.fadeInImageMediumUrl}",
          videoUrl: "${Utils.fadeInImageVideoUrl}"),
      ListItem(
          title: "${Utils.streamBuilder.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.streamBuilderDescription}",
          url: "${Utils.streamBuilderURL}",
          mediumUrl: "${Utils.streamBuilderMediumUrl}",
          videoUrl: "${Utils.streamBuilderVideoUrl}"),
      ListItem(
          title: "${Utils.inheritedModel.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.inheritedModelDescription}",
          url: "${Utils.inheritedModelURL}",
          mediumUrl: "${Utils.inheritedModelMediumUrl}",
          videoUrl: "${Utils.inheritedModelVideoUrl}"),
      ListItem(
          title: "${Utils.clipRRect.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.clipRRectDescription}",
          url: "${Utils.clipRRectURL}",
          mediumUrl: "${Utils.clipRrectMediumUrl}",
          videoUrl: "${Utils.clipRrectVideoUrl}"),
      ListItem(
          title: "${Utils.hero.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.heroDescription}",
          url: "${Utils.heroURL}",
          mediumUrl: "${Utils.heroMediumUrl}",
          videoUrl: "${Utils.heroVideoUrl}"),
      ListItem(
          title: "${Utils.customPaint.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.customPaintDescription}",
          url: "${Utils.customPaintURL}",
          mediumUrl: "${Utils.customPaintMediumUrl}",
          videoUrl: "${Utils.customPaintVideoUrl}"),
      ListItem(
          title: "${Utils.tooltip.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.tooltipDescription}",
          url: "${Utils.tooltipURL}",
          mediumUrl: "${Utils.toolTipMediumUrl}",
          videoUrl: "${Utils.toolTipVideoUrl}"),
      ListItem(
          title: "${Utils.fittedBox.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.fittedBoxDescription}",
          url: "${Utils.fittedBoxURL}",
          mediumUrl: "${Utils.safeAreaMediumUrl}",
          videoUrl: "${Utils.fittedBoxVideoUrl}"),
      ListItem(
          title: "${Utils.layoutBuilder.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.layoutBuilderDescription}",
          url: "${Utils.layoutBuilderURL}",
          mediumUrl: "${Utils.layoutBuilderMediumUrl}",
          videoUrl: "${Utils.layoutBuilderVideoUrl}"),
      ListItem(
          title: "${Utils.absorbPointer.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.absorbPointerDescription}",
          url: "${Utils.absorbPointerURL}",
          mediumUrl: "${Utils.absorbPointerMediumUrl}",
          videoUrl: "${Utils.absorbPointerVideoUrl}"),
      ListItem(
          title: "${Utils.transform.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.transformDescription}",
          url: "${Utils.transformURL}",
          mediumUrl: "${Utils.transformMediumUrl}",
          videoUrl: "${Utils.transformVideoUrl}"),
      ListItem(
          title: "${Utils.backDropFilter.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.backDropFilterDescription}",
          url: "${Utils.backDropFilterURL}",
          mediumUrl: "${Utils.backdropMediumUrl}",
          videoUrl: "${Utils.backdropVideoUrl}"),
      ListItem(
          title: "${Utils.align.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.alignDescription}",
          url: "${Utils.alignURL}",
          mediumUrl: "${Utils.alignMediumUrl}",
          videoUrl: "${Utils.alignVideoUrl}"),
      ListItem(
          title: "${Utils.positioned.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.positionedDescription}",
          url: "${Utils.positionedURL}",
          mediumUrl: "${Utils.positionedMediumUrl}",
          videoUrl: "${Utils.positionedVideoUrl}"),
      ListItem(
          title: "${Utils.animatedBuilder.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.animatedBuilderDescription}",
          url: "${Utils.animatedBuilderURL}",
          mediumUrl: "${Utils.animatedBuilderMediumUrl}",
          videoUrl: "${Utils.animatedBuilderVideoUrl}"),
      ListItem(
          title: "${Utils.dismissible.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.dismissibleDescription}",
          url: "${Utils.dismissibleURL}",
          mediumUrl: "${Utils.dismissibleMediumUrl}",
          videoUrl: "${Utils.dismissibleVideoUrl}"),
      ListItem(
          title: "${Utils.sizedBox.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.sizedBoxDescription}",
          url: "${Utils.sizedBoxURL}",
          mediumUrl: "${Utils.sizedBoxMediumUrl}",
          videoUrl: "${Utils.sizedBoxVideoUrl}"),
      ListItem(
          title:
              "${Utils.valueListenableBuilder.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.valueListenableBuilderDescription}",
          url: "${Utils.valueListenableBuilderURL}",
          mediumUrl: "${Utils.valueListenableBuilderMediumUrl}",
          videoUrl: "${Utils.valueListenableBuilderVideoUrl}"),
      ListItem(
          title: "${Utils.draggable.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.draggableDescription}",
          url: "${Utils.draggableURL}",
          mediumUrl: "${Utils.draggableMediumUrl}",
          videoUrl: "${Utils.draggableVideoUrl}"),
      ListItem(
          title: "${Utils.animatedList.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.animatedListDescription}",
          url: "${Utils.animatedListURL}",
          mediumUrl: "${Utils.animatedListMediumUrl}",
          videoUrl: "${Utils.animatedListVideoUrl}"),
      ListItem(
          title: "${Utils.flexible.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.flexibleDescription}",
          url: "${Utils.flexibleURL}",
          mediumUrl: "${Utils.flexibleMediumUrl}",
          videoUrl: "${Utils.flexibleVideoUrl}"),
      ListItem(
          title: "${Utils.mediaQuery.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.mediaQueryDescription}",
          url: "${Utils.mediaQueryURL}",
          mediumUrl: "${Utils.mediaqueryMediumUrl}",
          videoUrl: "${Utils.mediaqueryVideoUrl}"),
      ListItem(
          title: "${Utils.spacer.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.spacerDescription}",
          url: "${Utils.spacerURL}",
          mediumUrl: "${Utils.spacerMediumUrl}",
          videoUrl: "${Utils.spacerVideoUrl}"),
      ListItem(
          title: "${Utils.inheritedWidget.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.inheritedWidgetDescription}",
          url: "${Utils.inheritedWidgetURL}",
          mediumUrl: "${Utils.inheritedWidgetMediumUrl}",
          videoUrl: "${Utils.inheritedWidgetVideoUrl}"),
      ListItem(
          title: "${Utils.animatedIcon.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.animatedIconDescription}",
          url: "${Utils.animatedIconURL}",
          mediumUrl: "${Utils.animatedIconMediumUrl}",
          videoUrl: "${Utils.animatedIconVideoUrl}"),
      ListItem(
          title: "${Utils.aspectRatio.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.aspectRatioDescription}",
          url: "${Utils.aspectRatioURL}",
          mediumUrl: "${Utils.aspectRatioMediumUrl}",
          videoUrl: "${Utils.aspectRatioVideoUrl}"),
      ListItem(
          title: "${Utils.limitedBox.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.limitedBoxDescription}",
          url: "${Utils.limitedBoxURL}",
          mediumUrl: "${Utils.limitedBoxMediumUrl}",
          videoUrl: "${Utils.limitedBoxVideoUrl}"),
      ListItem(
          title: "${Utils.placeholder.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.placeholderDescription}",
          url: "${Utils.placeholderURL}",
          mediumUrl: "${Utils.placeholderMediumUrl}",
          videoUrl: "${Utils.placeholderVideoUrl}"),
      ListItem(
          title: "${Utils.richText.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.richTextDescription}",
          url: "${Utils.richTextURL}",
          mediumUrl: "${Utils.richTextMediumUrl}",
          videoUrl: "${Utils.richTextVideoUrl}"),
      ListItem(
          title:
              "${Utils.reorderableListView.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.reorderableListViewDescription}",
          url: "${Utils.reorderableListViewURL}",
          mediumUrl: "${Utils.reorderableListViewMediumUrl}",
          videoUrl: "${Utils.reorderableListViewVideoUrl}"),
      ListItem(
          title: "${Utils.animatedSwitcher.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.animatedSwitcherDescription}",
          url: "${Utils.animatedSwitcherURL}",
          mediumUrl: "${Utils.animatedSwitcherMediumUrl}",
          videoUrl: "${Utils.animatedSwitcherVideoUrl}"),
      ListItem(
          title: "${Utils.animatedPositioned.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.animatedPositionedDescription}",
          url: "${Utils.animatedPositionedURL}",
          mediumUrl: "${Utils.animatedPositionedMediumUrl}",
          videoUrl: "${Utils.animatedPositionedVideoUrl}"),
      ListItem(
          title: "${Utils.animatedPadding.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.animatedPaddingDescription}",
          url: "${Utils.animatedPaddingURL}",
          mediumUrl: "${Utils.animatedPaddingMediumUrl}",
          videoUrl: "${Utils.animatedPaddingVideoUrl}"),
      ListItem(
          title: "${Utils.indexedStack.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.indexedStackDescription}",
          url: "${Utils.indexedStackURL}",
          mediumUrl: "${Utils.indexedStackMediumUrl}",
          videoUrl: "${Utils.indexedStackVideoUrl}"),
      ListItem(
          title: "${Utils.semantics.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.semanticsDescription}",
          url: "${Utils.semanticsURL}",
          mediumUrl: "${Utils.semanticsMediumURL}",
          videoUrl: "${Utils.semanticsVideoURL}"),
      ListItem(
          title: "${Utils.constrainedBox.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.constrainedBoxDescription}",
          url: "${Utils.constrainedBoxURL}",
          mediumUrl: "${Utils.constrainedBoxMediumURL}",
          videoUrl: "${Utils.constrainedBoxVideoURL}"),
      ListItem(
          title: "${Utils.rateApp.replaceAll(new RegExp(r'/'), '')}",
          description: "${Utils.rateAppDescription}",
          url: "${Utils.rateAppURL}",
          mediumUrl: "${Utils.rateAppMediumURL}",
          videoUrl: "${Utils.rateAppVideoURL}"),
    ];
  }
}