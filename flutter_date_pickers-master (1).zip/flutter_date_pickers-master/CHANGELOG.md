## [0.0.6] - 21 November 2019
Added support for custom day decoration.
Added support for custom disabled days.

