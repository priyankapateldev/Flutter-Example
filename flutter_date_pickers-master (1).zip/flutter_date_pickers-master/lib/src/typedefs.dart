import 'package:flutter_date_pickers/src/unselectable_period_error.dart';

typedef void OnSelectionError(UnselectablePeriodException e);
