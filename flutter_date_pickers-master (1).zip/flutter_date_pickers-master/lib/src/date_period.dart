class DatePeriod {
  final DateTime start;
  final DateTime end;

  const DatePeriod(this.start, this.end);
}
