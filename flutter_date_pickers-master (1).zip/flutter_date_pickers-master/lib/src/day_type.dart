enum DayType {
  start,
  middle,
  end,
  single,
  disabled,
  notSelected
}