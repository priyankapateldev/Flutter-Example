## 0.0.1
___
Initial release.

## 0.1.0
___
Dart required version updated to 2.0.

## 0.1.2
___
Upgraded to latest gradle + kotlin versions

## 0.1.3
___
Add display flags

## 0.1.4
___
Capitalize Andorra's country name 

## 0.1.5
___
Added countries currency info

## 0.1.6
___
Added countries currency info